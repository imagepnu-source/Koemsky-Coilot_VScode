// app/tts/page.tsx (리팩토링 버전)
"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { parseScript, type ParsedScene } from "@/lib/tts-parser";
import { lookupWordDetail, translateToKorean } from "@/lib/tts-dictionary";
import { useTTSVoices } from "@/hooks/useTTSVoices";
import { useTTSSpeech } from "@/hooks/useTTSSpeech";
import { WordHoverPopup } from "@/components/tts/WordHoverPopup";
import { TranslationPopup } from "@/components/tts/TranslationPopup";
import { TTSControls } from "@/components/tts/TTSControls";

export default function TTSPage() {
  const [text, setText] = useState("");
  const [parsedScenes, setParsedScenes] = useState<ParsedScene[]>([]);
  const [selectedSceneId, setSelectedSceneId] = useState<number | null>(null);
  const [repeatCount, setRepeatCount] = useState(1);
  const [volume, setVolume] = useState(1);
  const [englishRate, setEnglishRate] = useState(1);
  const [koreanRate, setKoreanRate] = useState(1);
  const [storageReady, setStorageReady] = useState(false);
  const [translationPopupText, setTranslationPopupText] = useState<string | null>(null);
  const [hoverPopup, setHoverPopup] = useState<{
    word: string;
    phonetic?: string;
    englishDefs?: string[];
    koreanDefs?: string[];
    x: number;
    y: number;
  } | null>(null);

  const hoverTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hoverWordRef = useRef<string | null>(null);
  const hoverPosRef = useRef<{ x: number; y: number } | null>(null);
  const wordLoopRef = useRef<{ active: boolean; word: string } | null>(null);

  const {
    englishVoices,
    koreanVoices,
    englishVoiceName,
    setEnglishVoiceName,
    koreanVoiceName,
    setKoreanVoiceName,
    voiceInitializedRef,
  } = useTTSVoices();

  const { speaking, speakMessage, handleStop } = useTTSSpeech(
    volume,
    englishRate,
    koreanRate,
    englishVoiceName,
    koreanVoiceName,
    repeatCount
  );

  const currentScene = useMemo(() => {
    if (!parsedScenes.length) return null;
    if (selectedSceneId == null) return parsedScenes[0];
    return parsedScenes.find((s) => s.id === selectedSceneId) ?? parsedScenes[0];
  }, [parsedScenes, selectedSceneId]);

  // localStorage 로드
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      let settings: any = null;
      try {
        const settingsRaw = window.localStorage.getItem("tts_settings");
        if (settingsRaw) settings = JSON.parse(settingsRaw);
      } catch (e) {
        console.warn("[TTS] Failed to parse tts_settings:", e);
      }

      const stored = window.localStorage.getItem("tts_script_text");
      if (stored != null) {
        setText(stored);
        const trimmed = stored.trim();
        if (trimmed) {
          const scenes = parseScript(trimmed);
          setParsedScenes(scenes);
          let nextSelected: number | null = scenes.length ? scenes[0].id : null;
          if (
            settings &&
            typeof settings.selectedSceneId === "number" &&
            scenes.some((s) => s.id === settings.selectedSceneId)
          ) {
            nextSelected = settings.selectedSceneId;
          }
          setSelectedSceneId(nextSelected);
        }
      }

      if (settings) {
        if (typeof settings.englishRate === "number") setEnglishRate(settings.englishRate);
        if (typeof settings.koreanRate === "number") setKoreanRate(settings.koreanRate);
        if (typeof settings.volume === "number") setVolume(settings.volume);
        if (typeof settings.repeatCount === "number") setRepeatCount(settings.repeatCount);
        if (typeof settings.englishVoiceName === "string") setEnglishVoiceName(settings.englishVoiceName);
        if (typeof settings.koreanVoiceName === "string") setKoreanVoiceName(settings.koreanVoiceName);
        voiceInitializedRef.current = true;
      }
    } catch (e) {
      console.warn("[TTS] Failed to load from localStorage:", e);
    } finally {
      setStorageReady(true);
    }
  }, [setEnglishVoiceName, setKoreanVoiceName, voiceInitializedRef]);

  // 스크립트 자동 저장
  useEffect(() => {
    if (typeof window === "undefined" || !storageReady) return;
    try {
      window.localStorage.setItem("tts_script_text", text);
    } catch (e) {
      console.warn("[TTS] Failed to save script:", e);
    }
  }, [text, storageReady]);

  // 설정 자동 저장
  useEffect(() => {
    if (typeof window === "undefined" || !storageReady) return;
    try {
      const settings = {
        selectedSceneId,
        englishRate,
        koreanRate,
        volume,
        repeatCount,
        englishVoiceName,
        koreanVoiceName,
      };
      window.localStorage.setItem("tts_settings", JSON.stringify(settings));
    } catch (e) {
      console.warn("[TTS] Failed to save settings:", e);
    }
  }, [
    selectedSceneId,
    englishRate,
    koreanRate,
    volume,
    repeatCount,
    englishVoiceName,
    koreanVoiceName,
    storageReady,
  ]);

  const handleClear = () => {
    setText("");
    setParsedScenes([]);
    setSelectedSceneId(null);
    if (typeof window !== "undefined") {
      try {
        window.localStorage.removeItem("tts_script_text");
        window.localStorage.removeItem("tts_settings");
      } catch {
        // ignore
      }
    }
  };

  const handleSave = () => {
    const trimmed = text.trim();
    if (!trimmed) {
      alert("저장할 텍스트가 없습니다.");
      return;
    }
    const scenes = parseScript(trimmed);
    setParsedScenes(scenes);
    setSelectedSceneId(scenes.length ? scenes[0].id : null);
  };

  const startWordPronounceLoop = (word: string) => {
    const trimmed = word.trim();
    if (!trimmed) return;

    if (
      wordLoopRef.current &&
      wordLoopRef.current.active &&
      wordLoopRef.current.word === trimmed
    ) {
      return;
    }

    wordLoopRef.current = { active: true, word: trimmed };

    const speakOnce = () => {
      const loop = wordLoopRef.current;
      if (!loop || !loop.active || loop.word !== trimmed) return;

      speakMessage(trimmed, "en", {
        repeatOverride: 1,
        onDone: () => {
          const again = wordLoopRef.current;
          if (again && again.active && again.word === trimmed) {
            speakOnce();
          }
        },
      });
    };

    speakOnce();
  };

  const stopWordPronounceLoop = () => {
    if (wordLoopRef.current) {
      wordLoopRef.current.active = false;
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center bg-slate-50 py-4">
      <div className="w-full max-w-2xl bg-white rounded shadow p-4 space-y-4">
        <h1 className="text-lg font-semibold">TTS (대본 읽어주기)</h1>

        <div className="space-y-2">
          <div className="text-sm text-gray-700">대본 입력 창:</div>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="여기에 대사를 입력하세요"
            className="h-[50px] text-sm"
          />
          <div className="flex justify-end gap-2 text-sm">
            <Button variant="outline" size="sm" onClick={handleClear}>
              지움
            </Button>
            <Button size="sm" onClick={handleSave}>
              저장
            </Button>
          </div>
        </div>

        <div className="border rounded p-2 space-y-2" style={{ height: 700, overflowY: "auto" }}>
          <TTSControls
            volume={volume}
            onVolumeChange={setVolume}
            englishRate={englishRate}
            onEnglishRateChange={setEnglishRate}
            koreanRate={koreanRate}
            onKoreanRateChange={setKoreanRate}
            englishVoiceName={englishVoiceName}
            onEnglishVoiceChange={setEnglishVoiceName}
            koreanVoiceName={koreanVoiceName}
            onKoreanVoiceChange={setKoreanVoiceName}
            englishVoices={englishVoices}
            koreanVoices={koreanVoices}
          />

          <div className="flex items-center justify-between text-sm text-gray-600 mb-1">
            <div className="flex items-center gap-2">
              <span>Scene</span>
              <select
                className="border rounded px-1 py-0.5 text-sm"
                value={currentScene ? currentScene.id : ""}
                onChange={(e) => setSelectedSceneId(Number(e.target.value) || null)}
                disabled={!parsedScenes.length}
              >
                {parsedScenes.length === 0 && <option value="">(저장 후 자동 생성)</option>}
                {parsedScenes.map((s) => (
                  <option key={s.id} value={s.id}>
                    {`Scene ${s.sceneNumber}${s.title ? ": " + s.title : ""}`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {currentScene ? (
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between font-semibold">
                <div>{`Scene ${currentScene.sceneNumber}: ${currentScene.title || ""}`}</div>
                <div className="flex flex-col items-end gap-1">
                  <div className="flex items-center gap-2 text-sm font-normal">
                    <span>재생 횟수:</span>
                    <select
                      className="border rounded px-1 py-0.5 text-sm"
                      value={repeatCount}
                      onChange={(e) => setRepeatCount(Number(e.target.value) || 1)}
                    >
                      {[1, 3, 5, 7, 9].map((n) => (
                        <option key={n} value={n}>{n}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-2 text-sm font-normal">
                    <Button
                      size="sm"
                      className="h-7 px-3 text-sm"
                      onClick={() => {
                        const sceneText = currentScene.lines
                          .map((line) => `${line.speaker}: ${line.sentences.join(" ")}`)
                          .join(" ");
                        speakMessage(sceneText, "en");
                      }}
                    >
                      Play
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="h-7 px-3 text-sm"
                      onClick={handleStop}
                    >
                      Stop
                    </Button>
                  </div>
                </div>
              </div>

              {currentScene.lines.map((line) => {
                const combinedMessage = line.sentences.join("\n");
                const isSingleSentence = line.sentences.length <= 1;
                const textAreaHeightClass = isSingleSentence ? "h-[50px]" : "h-[100px]";

                return (
                  <div key={line.id} className="border rounded p-2 flex items-stretch gap-2">
                    <div className="w-24 flex flex-col items-center justify-start gap-2">
                      <div className="w-full font-semibold text-sm text-left">
                        {line.speaker}:
                      </div>
                      <div className="w-full flex items-center justify-center gap-1">
                        <Button
                          size="sm"
                          className="h-7 px-3 text-sm"
                          onClick={() => {
                            const msg = `${line.speaker}: ${combinedMessage}`;
                            speakMessage(msg, "en");
                          }}
                        >
                          Play
                        </Button>
                        <Button
                          size="sm"
                          className="h-7 px-3 text-sm bg-sky-100 text-sky-700 border border-sky-300 hover:bg-sky-200"
                          onClick={async () => {
                            const original = combinedMessage.replace(/\n/g, " ");
                            const translated = await translateToKorean(original);
                            if (!translated) return;
                            setTranslationPopupText(translated);

                            const hasHangul = /[가-힣]/.test(translated);
                            speakMessage(hasHangul ? translated : original, hasHangul ? "ko" : "en", {
                              onDone: () => setTranslationPopupText(null),
                            });
                          }}
                        >
                          해석
                        </Button>
                      </div>
                    </div>

                    <div
                      className={`text-sm flex-1 ${textAreaHeightClass} border rounded px-2 py-1 bg-slate-50 overflow-y-auto whitespace-pre-wrap`}
                    >
                      {combinedMessage.split(/(\s+)/).map((part, idx) => {
                        if (part.match(/^\s+$/)) return part;
                        const clean = part.replace(/[^A-Za-z']/g, "");
                        if (!clean) return <span key={idx}>{part}</span>;

                        return (
                          <span
                            key={idx}
                            className="cursor-pointer hover:bg-yellow-100"
                            onMouseEnter={(e) => {
                              if (hoverTimerRef.current) clearTimeout(hoverTimerRef.current);
                              hoverWordRef.current = clean;
                              const rect = (e.target as HTMLElement).getBoundingClientRect();
                              hoverPosRef.current = {
                                x: rect.left + window.scrollX,
                                y: rect.bottom + window.scrollY + 30,
                              };
                              hoverTimerRef.current = setTimeout(async () => {
                                if (hoverWordRef.current !== clean) return;
                                const detail = await lookupWordDetail(clean);
                                const pos = hoverPosRef.current;
                                if (!pos || hoverWordRef.current !== clean) return;
                                setHoverPopup({
                                  word: clean,
                                  phonetic: detail.phonetic,
                                  englishDefs: detail.englishDefs,
                                  koreanDefs: detail.koreanDefs,
                                  x: pos.x,
                                  y: pos.y,
                                });
                              }, 100);
                            }}
                            onMouseLeave={() => {
                              if (hoverTimerRef.current) {
                                clearTimeout(hoverTimerRef.current);
                                hoverTimerRef.current = null;
                              }
                              hoverWordRef.current = null;
                              hoverPosRef.current = null;
                              setHoverPopup(null);
                            }}
                            onMouseDown={(e) => {
                              if (e.button === 0) {
                                e.preventDefault();
                                startWordPronounceLoop(clean);
                              }
                            }}
                            onMouseUp={(e) => {
                              if (e.button === 0) {
                                e.preventDefault();
                                stopWordPronounceLoop();
                              }
                            }}
                          >
                            {part}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                );
              })}

              {hoverPopup && <WordHoverPopup {...hoverPopup} />}
              {translationPopupText && (
                <TranslationPopup
                  text={translationPopupText}
                  onClose={() => setTranslationPopupText(null)}
                />
              )}
            </div>
          ) : (
            <div className="text-sm text-gray-500">
              저장된 Scene 이 없습니다. 위에 스크립트를 입력하고 저장을 눌러 주세요.
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
